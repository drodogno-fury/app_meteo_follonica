# 🚀 Come ottenere l'APK gratis con GitHub Actions

## Prerequisiti
- Account GitHub gratuito (github.com)
- Il progetto MeteoMarFollonica già scaricato

---

## PASSO 1 — Crea un account GitHub
1. Vai su https://github.com/signup
2. Registrati gratuitamente

---

## PASSO 2 — Crea un nuovo Repository
1. Clicca sul "+" in alto a destra → "New repository"
2. Nome: `MeteoMarFollonica`
3. Visibilità: **Public** (gratis) o Private
4. NON spuntare "Add README"
5. Clicca "Create repository"

---

## PASSO 3 — Carica i file del progetto
1. Nella pagina del repo clicca "uploading an existing file"
2. Apri la cartella ZIP estratta → entra in `MeteoMarFollonica/`
3. Seleziona TUTTI i file e cartelle dentro (app/, build.gradle, settings.gradle, ecc.)
4. Trascinali nella pagina GitHub
5. Clicca "Commit changes"

---

## PASSO 4 — Aggiungi il file build.yml
1. Clicca "Add file" → "Create new file"
2. Nel nome scrivi esattamente: `.github/workflows/build.yml`
3. Copia e incolla il contenuto del file `build.yml` che trovi in questo ZIP
4. Clicca "Commit new file"

---

## PASSO 5 — Aspetta la compilazione (5-10 minuti)
1. Clicca sulla scheda "Actions" del repository
2. Vedrai un job in esecuzione con un cerchio giallo ⏳
3. Quando diventa verde ✅ l'APK è pronto!

---

## PASSO 6 — Scarica l'APK sul telefono
1. Clicca sul job verde in "Actions"
2. In fondo alla pagina trovi "Artifacts"
3. Clicca su "MeteoMar-Follonica-APK" per scaricare lo ZIP
4. Estrai lo ZIP → trovi `app-debug.apk`
5. Invia l'APK al telefono (Google Drive, WhatsApp, email...)
6. Aprilo sul telefono per installarlo

---

## ⚠️ Prima di installare l'APK
Sul telefono Android devi abilitare "Origini sconosciute":
- Android 8+: Impostazioni → App → Chrome (o il browser usato) → Installa app sconosciute → Attiva
- Android 7: Impostazioni → Sicurezza → Origini sconosciute → Attiva

---

## ✅ Fatto!
L'app MeteoMar Follonica è installata sul tuo telefono!
